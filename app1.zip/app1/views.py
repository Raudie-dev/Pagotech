from django.shortcuts import render, redirect
from django.urls import reverse
import django.contrib.messages as messages
from django.contrib.auth.hashers import check_password  
from .models import Cliente, LinkPago
from . import crud
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from django.http import HttpResponse, Http404, JsonResponse
from django.core.paginator import Paginator
from django.template.loader import get_template
from django.conf import settings
from django.template.loader import render_to_string
from weasyprint import HTML
import tempfile
from app2.models import ParametroFinanciero, CuotaConfig
import os
import logging
from app2 import crud as app2_crud
from django.core.mail import send_mail
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
from utils.email_utils import mail
from django.urls import reverse
from django.utils import timezone
import re
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from app2.models import TarjetaCustom

logger = logging.getLogger('app1')


def index(request):
    logger.debug("Vista index cargada")
    return render(request, 'index.html')


def register(request):
    if request.method == 'POST':
        # --- 1. OBTENER Y SANITIZAR DATOS ---
        nombre_raw = request.POST.get('nombre', '').strip()
        # Eliminar espacios múltiples y capitalizar cada palabra
        nombre = re.sub(r'\s+', ' ', nombre_raw).title()
        
        email_raw = request.POST.get('email', '').strip()
        email = email_raw.lower()
        
        telefono_raw = request.POST.get('telefono', '').strip()
        telefono = re.sub(r'\s+', '', telefono_raw) if telefono_raw else ''
        
        password = request.POST.get('password', '')
        password2 = request.POST.get('password2', '')

        logger.debug(f"Intento de registro — email={email} nombre={nombre}")

        # --- 2. VALIDACIONES ---
        errors = []

        # Nombre
        if not nombre:
            errors.append('El nombre completo es obligatorio.')
        elif len(nombre) < 3:
            errors.append('El nombre debe tener al menos 3 caracteres.')
        elif len(nombre) > 100:
            errors.append('El nombre no puede exceder 100 caracteres.')
        elif not re.match(r'^[a-zA-ZÀ-ÿ\s]+$', nombre):
            errors.append('El nombre solo puede contener letras y espacios.')

        # Email
        if not email:
            errors.append('El correo electrónico es obligatorio.')
        else:
            try:
                validate_email(email)
            except ValidationError:
                errors.append('Ingresa un correo electrónico válido.')

        # Teléfono (opcional pero con formato)
        if not telefono:
            errors.append('El teléfono es obligatorio.')
        elif not re.match(r'^\+?[0-9]{8,15}$', telefono):
            errors.append('Debe comenzar con + y solo números (8-15 dígitos).')

        # Nombre de usuario
        username_val = request.POST.get('username', '').strip().lower()
        if not username_val:
            errors.append('El nombre de usuario es obligatorio.')
        elif len(username_val) < 3:
            errors.append('El nombre de usuario debe tener al menos 3 caracteres.')
        elif not username_val.replace('_', '').replace('.', '').isalnum():
            errors.append('El nombre de usuario solo puede contener letras, números, puntos y guiones bajos.')

        # Contraseña
        if not password:
            errors.append('La contraseña es obligatoria.')
        else:
            if len(password) < 8:
                errors.append('La contraseña debe tener al menos 8 caracteres.')
            if not re.search(r'[A-Z]', password):
                errors.append('La contraseña debe contener al menos una mayúscula.')
            if not re.search(r'[!@#$%^&*()_\-+=\[\]{}|:;"\'\'<>,.?/~`]', password):
                errors.append('La contraseña debe contener al menos un símbolo.')

        # Confirmación de contraseña
        if password != password2:
            errors.append('Las contraseñas no coinciden.')

        # Si hay errores, mostrar y retornar
        if errors:
            logger.warning(f"Registro rechazado — email={email} — errores={errors}")
            for e in errors:
                messages.error(request, e)
            return render(request, 'register.html', {
                'data': request.POST,
                'errors': errors
            })

        # --- 3. CREAR CLIENTE (CRUD) ---
        cliente, creation_errors = crud.create_cliente(nombre, password, email, telefono, username=username_val)

        if creation_errors:
            logger.warning(f"Registro rechazado — email={email} — errores={creation_errors}")
            for e in creation_errors:
                messages.error(request, e)
            return render(request, 'register.html', {
                'data': request.POST,
                'errors': creation_errors
            })

        # --- 4. ENVIAR NOTIFICACIÓN POR CORREO ---
        try:
            admin_url = request.build_absolute_uri(reverse('aprobacion'))
            
            logger.info(f"Intentando enviar correo de notificación para {email}")
            
            # Usar EMAIL_RECEPTORES (lista) o EMAIL_RECEPTOR (string) según tu settings
            destinatarios = getattr(settings, 'EMAIL_RECEPTORES', None)
            if not destinatarios:
                destinatarios = [getattr(settings, 'EMAIL_RECEPTOR', 'pagotechnotificaciones@gmail.com')]
            
            resultado = mail(
                asunto="Nuevo usuario registrado - Pendiente de aprobación",
                destinatarios=destinatarios,
                template_html="emails/notificacion_registro.html",
                contexto={
                    "nombre": nombre,
                    "email": email,
                    "telefono": telefono or "No especificado",
                    "fecha": timezone.now().strftime("%d/%m/%Y %H:%M"),
                    "admin_url": admin_url,
                },
            )
            
            if resultado:
                logger.info(f"Correo de notificación enviado correctamente para {email}")
            else:
                logger.warning(f"Falló el envío del correo de notificación para {email}")
                
        except Exception as e:
            logger.error(f"Error enviando correo de notificación para {email}: {e}")

        # --- 5. REDIRIGIR AL INDEX CON MENSAJE DE ÉXITO ---
        logger.info(f"Registro exitoso — email={email} nombre={nombre} id={cliente.id}")
        return redirect(f"{reverse('index')}?registered=1")

    # --- GET: mostrar formulario vacío ---
    logger.debug("GET register — formulario cargado")
    return render(request, 'register.html')

def login_cliente(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        email    = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')

        logger.debug(f"Intento de login — username={username} email={email}")

        cliente, error_msg = crud.login_cliente_auth(username, email, password)

        if error_msg:
            messages.error(request, error_msg)
        else:
            logger.info(f"Login exitoso — id={cliente.id} username={username} rol={cliente.rol}")
            request.session['user_id'] = cliente.id
            request.session['user_rol'] = cliente.rol
            messages.success(request, f"Bienvenido {cliente.nombre}")
            # Secundarios van directo a crear link
            if cliente.es_secundario:
                return redirect('crear_link')
            return redirect('dashboard')

    return render(request, 'login.html')

TYC_VERSION_ACTUAL = "1.0"  # Cambiar esto fuerza re-aceptación a todos

def _get_tyc_version_actual():
    try:
        from app2.models import TerminosCondiciones
        tyc = TerminosCondiciones.objects.filter(activa=True).first()
        return tyc.version if tyc else "1.0"
    except Exception:
        return "1.0"
    
def tyc(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login_cliente')

    from app2.models import TerminosCondiciones

    tyc_obj = TerminosCondiciones.objects.filter(activa=True).first()
    version_actual = tyc_obj.version if tyc_obj else TYC_VERSION_ACTUAL

    if request.method == 'POST':
        cliente = crud.get_cliente(user_id)
        cliente.acepto_tyc    = True
        cliente.fecha_acepto_tyc = timezone.now()
        cliente.version_tyc   = version_actual
        cliente.save()
        logger.info(f"TyC aceptados — usuario={user_id} version={version_actual}")
        return redirect('dashboard')

    return render(request, 'tyc.html', {
        'version':  version_actual,
        'tyc_obj':  tyc_obj,
    })

def dashboard(request):
    user_id = request.session.get('user_id')
    if not user_id:
        logger.debug("Dashboard — sesión no encontrada, redirigiendo a login")
        return redirect('login_cliente')

    cliente = crud.get_cliente(user_id)
    if not cliente:
        logger.warning(f"Dashboard — cliente id={user_id} no encontrado en DB, redirigiendo")
        return redirect('login_cliente')

    # Los usuarios secundarios no acceden al dashboard
    if cliente.es_secundario:
        return redirect('crear_link')
    
    # ── Guard TyC ──────────────────────────────────────────────
    if not cliente.acepto_tyc or cliente.version_tyc != _get_tyc_version_actual():
        return redirect('tyc')

    stats = crud.get_dashboard_stats(user_id)
    logger.debug(
        f"Dashboard cargado — usuario={cliente.nombre} id={user_id} "
        f"links={stats['total_links']} pagados={stats['total_payments']} pendientes={stats['pending_payments']}"
    )

    context = {
        'user': cliente,
        'total_links': stats['total_links'],
        'total_payments': stats['total_payments'],
        'pending_payments': stats['pending_payments'],
    }
    return render(request, 'dashboard.html', context)


def creacion_link(request):
    user_id = request.session.get('user_id')
    if not user_id:
        logger.debug("Creación link — sesión no encontrada, redirigiendo a login")
        return redirect('login_cliente')

    cliente = crud.get_cliente(user_id)

    # Para usuarios secundarios: el cliente del negocio es el principal
    cliente_negocio = cliente.principal if cliente.es_secundario else cliente
    cliente_pk_negocio = cliente_negocio.id

    config = ParametroFinanciero.objects.first()
    if not config:
        logger.warning("Creación link — ParametroFinanciero no configurado, usando fallback")
        config = ParametroFinanciero.objects.create()

    planes_activos = app2_crud.list_cuotas_para_usuario(cliente_pk_negocio)
    logger.debug(f"Creación link — usuario={cliente.nombre} id={user_id} planes_activos={planes_activos.count()}")

    if request.method == 'POST':

        # --- CASO A: AJAX Preview ---
        if 'preview' in request.POST:
            try:
                # Modelo TRASLADA: monto ingresado = lo que quiere RECIBIR el comercio
                monto_neto    = Decimal(request.POST.get('monto', '0'))
                cuotas_num    = int(request.POST.get('cuotas', '1'))
                tipo          = request.POST.get('tipo_tarjeta', 'credito')

                if tipo == 'debito':
                    cuotas_num = 1
                    iva_f    = Decimal(str(config.iva)) / 100
                    pt_eff   = Decimal(str(config.comision_pago_tech_debito)) * (1 + iva_f)
                    ar_eff   = Decimal(str(config.arancel_plataforma_debito)) * (1 + iva_f)
                    tasa_eff = Decimal('0')
                else:
                    # Buscar plan según tipo de tarjeta
                    if tipo.startswith('custom_'):
                        slug = tipo.replace('custom_', '')
                        plan = app2_crud.list_cuotas_para_tarjeta_custom(
                            user_id, slug
                        ).filter(numero_cuota=cuotas_num).first()
                    else:
                        plan = app2_crud.list_cuotas_para_usuario(user_id).filter(
                            numero_cuota=cuotas_num
                        ).first()

                    if plan and cuotas_num > 1:
                        iva_val     = plan.iva_override              if plan.iva_override is not None              else config.iva
                        iva_fin_val = plan.iva_financiacion_override if plan.iva_financiacion_override is not None else config.iva_financiacion
                        com_val     = plan.com_credito_override      if plan.com_credito_override is not None      else config.comision_pago_tech
                        ar_val      = plan.arancel_credito_override  if plan.arancel_credito_override is not None  else config.arancel_plataforma

                        iva_f     = Decimal(str(iva_val))     / 100
                        iva_fin_f = Decimal(str(iva_fin_val)) / 100

                        tasa_eff = Decimal(str(plan.tasa_base)) * (1 + iva_fin_f) if plan.tasa_aplica_iva_fin else Decimal(str(plan.tasa_base))
                        pt_eff   = Decimal(str(com_val))        * (1 + iva_f)     if plan.comision_aplica_iva  else Decimal(str(com_val))
                        ar_eff   = Decimal(str(ar_val))         * (1 + iva_f)     if plan.comision_aplica_iva  else Decimal(str(ar_val))
                    else:
                        # Contado o fallback global
                        iva_f    = Decimal(str(config.iva)) / 100
                        pt_eff   = Decimal(str(config.comision_pago_tech)) * (1 + iva_f)
                        ar_eff   = Decimal(str(config.arancel_plataforma)) * (1 + iva_f)
                        tasa_eff = Decimal('0')

                total_desc = tasa_eff + pt_eff + ar_eff

                # Modelo TRASLADA: calcular monto que paga el cliente
                monto_cliente   = (monto_neto / (1 - total_desc / 100)).quantize(
                    Decimal('0.01'), rounding=ROUND_HALF_UP
                )
                descuento_pesos = (monto_cliente - monto_neto).quantize(
                    Decimal('0.01'), rounding=ROUND_HALF_UP
                )

                return JsonResponse({
                    'success':     True,
                    'monto_venta': float(monto_cliente),    # lo que paga el cliente
                    'comision':    float(descuento_pesos),  # aranceles trasladados al cliente
                    'neto':        float(monto_neto)        # lo que recibe el comercio (= lo ingresado)
                })
            except Exception as e:
                logger.error(f"Error en preview — usuario={user_id}: {e}")
                return JsonResponse({'success': False})
        # --- CASO B: Confirmación y Generación Final ---
        if 'confirm' in request.POST:
            monto_contado = request.POST.get('monto', '').strip()
            cuotas = request.POST.get('cuotas', '1')
            tipo = request.POST.get('tipo_tarjeta', 'credito')
            desc = request.POST.get('descripcion', '').strip()

            logger.info(
                f"Generando link — usuario={user_id} monto={monto_contado} "
                f"tipo={tipo} cuotas={cuotas} descripcion='{desc}'"
            )

            link_obj, errors = crud.create_link(
                cliente_pk_negocio, monto_contado, int(cuotas), tipo, desc,
                creado_por_pk=user_id
            )

            if not errors:
                logger.info(
                    f"Link generado OK — usuario={user_id} order_id={link_obj.order_id} "
                    f"monto_bruto={link_obj.monto} neto={link_obj.receiver_amount} "
                    f"comision={link_obj.commission_amount}"
                )
                if link_obj.payzen_card_code:
                    final_url = request.build_absolute_uri(reverse('pagar_link', kwargs={'order_id': link_obj.order_id}))
                else:
                    final_url = link_obj.link
                request.session['link_recien_creado'] = {'url': final_url, 'monto_total': float(link_obj.monto)}
                messages.success(request, "¡Enlace de pago generado con éxito!")
                return redirect('crear_link')
            else:
                logger.error(f"Error generando link — usuario={user_id} errores={errors}")
                for e in errors:
                    messages.error(request, e)

    # GET — Carga de tabla
    # Los secundarios ven solo sus propios links; los principales ven todos los del negocio
    if cliente.es_secundario:
        all_links = crud.list_links_for_cliente(cliente_pk_negocio).filter(creado_por=cliente)
    else:
        all_links = crud.list_links_for_cliente(cliente_pk_negocio).select_related('creado_por')

    paginator = Paginator(all_links, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    link_creado = request.session.pop('link_recien_creado', None)
    tarjetas_custom = TarjetaCustom.objects.filter(activa=True).order_by('orden', 'nombre')

    logger.debug(f"Creación link GET — usuario={user_id} total_links={all_links.count()}")

    from app2 import crud as admin_crud
    import json
    planes_credito = admin_crud.list_cuotas_para_usuario(cliente_pk_negocio)

    tarjetas_custom = TarjetaCustom.objects.filter(activa=True).order_by('orden', 'nombre')

    planes_por_tarjeta = {}
    for tc in tarjetas_custom:
        if tc.acepta_cuotas:
            planes = admin_crud.list_cuotas_para_tarjeta_custom(cliente_pk_negocio, tc.slug)
            planes_por_tarjeta[tc.slug] = [
                {'numero_cuota': p.numero_cuota, 'nombre': p.nombre}
                for p in planes
            ]

    return render(request, 'creacion_link.html', {
        'user':              cliente,
        'cliente_negocio':   cliente_negocio,
        'es_operador':       cliente.es_secundario,
        'links':             page_obj,
        'planes':            planes_activos,
        'link_creado':       link_creado,
        'tarjetas_custom':   tarjetas_custom,
        'config':            config,
        'planes':            planes_credito,
        'planes_por_tarjeta': json.dumps(planes_por_tarjeta),
        'tarjetas_custom':   tarjetas_custom
    })


def verificar_estado_pago_ajax(request, link_id):
    user_id = request.session.get('user_id')
    if not user_id:
        logger.warning(f"Verificación de pago sin sesión — link_id={link_id}")
        return JsonResponse({'error': 'No autorizado'}, status=401)

    logger.debug(f"Verificando estado de pago — link_id={link_id} usuario={user_id}")

    resultado_crud = crud.verificar_estado_pago(link_id)

    logger.debug(
        f"Resultado verificación — link_id={link_id} "
        f"pagado={resultado_crud['pagado']} anulado={resultado_crud['anulado']} "
        f"status={resultado_crud['status']}"
    )

    if resultado_crud['pagado']:
        logger.info(f"Pago confirmado — link_id={link_id} usuario={user_id} cuotas={resultado_crud['cuotas']}")
    elif resultado_crud['anulado']:
        logger.warning(f"Pago anulado/rechazado — link_id={link_id} usuario={user_id} status={resultado_crud['status']}")

    mensajes = {
        'AUTHORISED': 'Pago Autorizado',
        'CAPTURED': 'Pago Exitoso',
        'REFUSED': 'Pago Rechazado por el Banco',
        'CANCELLED': 'Pago Cancelado por el Usuario',
        'EXPIRED': 'El link ha expirado',
        'PENDING': 'Esperando pago...',
        'ABANDONED': 'El cliente abandonó el pago'
    }

    estado_texto = mensajes.get(resultado_crud['status'], resultado_crud['status'])

    return JsonResponse({
        'pagado': resultado_crud['pagado'],
        'anulado': resultado_crud['anulado'],
        'status_raw': resultado_crud['status'],
        'status_txt': estado_texto,
        'cuotas': resultado_crud['cuotas'],
        'id': link_id
    })


def logout_cliente(request):
    user_id = request.session.get('user_id')
    logger.info(f"Logout — usuario id={user_id}")
    request.session.flush()
    return redirect('login_cliente')


def ticket_pdf(request, link_id):
    user_id       = request.session.get('user_id')
    user_admin_id = request.session.get('user_admin_id')

    # Permite acceso si es cliente autenticado O si es admin
    if not user_id and not user_admin_id:
        return redirect('login_cliente')

    logger.info(f"Generando PDF — link_id={link_id} usuario={user_id} admin={user_admin_id}")

    try:
        # Admin puede ver el PDF de cualquier cliente
        # Cliente solo puede ver sus propios PDFs
        if user_admin_id:
            link = LinkPago.objects.get(id=link_id)
        else:
            link = LinkPago.objects.get(id=link_id, cliente_id=user_id)
            
        config = ParametroFinanciero.objects.first()

        if not config:
            return HttpResponse("Configuración financiera no encontrada.", status=500)

        monto = Decimal(str(link.monto))

        # ── Leer desglose congelado directamente de la DB ──────────────
        # Si el link fue creado antes de esta migración, los campos
        # tendrán valor 0 — en ese caso recalculamos como fallback
        tiene_desglose = link.desglose_arancel + link.desglose_comision + link.desglose_tasa > 0

        if tiene_desglose:
            ar_monto    = link.desglose_arancel
            com_monto   = link.desglose_comision
            tasa_monto  = link.desglose_tasa
            iva_21      = link.desglose_iva_21
            iva_105     = link.desglose_iva_105
            cuota_valor = link.desglose_cuota_valor
            logger.debug(f"PDF — usando desglose congelado de DB — link_id={link_id}")
        else:
            # Fallback para links anteriores a la migración
            logger.warning(f"PDF — desglose no guardado, recalculando — link_id={link_id}")
            total_commission = Decimal(str(link.commission_amount))
            cuota_valor = (monto / link.cuotas_elegidas).quantize(Decimal('0.01'), ROUND_HALF_UP)
            ar_monto    = (total_commission / 3).quantize(Decimal('0.01'), ROUND_HALF_UP)
            tasa_monto  = (total_commission / 3).quantize(Decimal('0.01'), ROUND_HALF_UP)
            com_monto   = total_commission - ar_monto - tasa_monto
            iva_21      = Decimal('0.00')
            iva_105     = Decimal('0.00')

        logger.debug(
            f"PDF — ar={ar_monto} com={com_monto} tasa={tasa_monto} "
            f"iva_21={iva_21} iva_105={iva_105}"
        )

        context = {
            'link':     link,
            'cliente':  link.cliente,
            'config':   config,
            'desglose': {
                'arancel':     ar_monto,
                'servicio':    com_monto,
                'costo_finan': tasa_monto,
                'iva_21':      iva_21,
                'iva_105':     iva_105,
                'cuota_valor': cuota_valor,
            },
            'liq_nro':  link.auth_code if link.auth_code else f"00{link.id}",
            'lote_nro': link.lote_number if link.lote_number else "001",
        }

        html_string = render_to_string('ticket_pdf.html', context)
        html        = HTML(string=html_string, base_url=request.build_absolute_uri())
        pdf_file    = html.write_pdf()

        response = HttpResponse(pdf_file, content_type='application/pdf')
        filename  = f"Liquidacion_{link.auth_code if link.auth_code else link.id}.pdf"
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

    except LinkPago.DoesNotExist:
        return HttpResponse("El comprobante solicitado no existe.", status=404)
    except Exception as e:
        logger.exception(f"PDF — error inesperado — link_id={link_id}: {e}")
        return HttpResponse(f"Error interno: {str(e)}", status=500)

def download_ticket(request, link_id):
    user_id = request.session.get('user_id')
    if not user_id:
        logger.debug(f"Download ticket sin sesión — link_id={link_id}")
        return redirect('login_cliente')

    logger.debug(f"Descargando ticket TXT — link_id={link_id} usuario={user_id}")

    filename, content, errors = crud.get_invoice_for_link(link_id, user_id)

    if errors:
        logger.warning(f"Download ticket — error obteniendo invoice — link_id={link_id} errores={errors}")
        return redirect('creacion_link')

    logger.info(f"Ticket TXT descargado — link_id={link_id} usuario={user_id} filename={filename}")

    response = HttpResponse(content, content_type='text/plain; charset=utf-8')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


def pagar_link(request, order_id):
    """
    Página de aterrizaje inteligente para redirigir al cliente de forma transparente
    directamente al formulario de captura de datos de la tarjeta en PayZen.
    """
    logger.debug(f"pagar_link — accediendo con order_id={order_id}")
    try:
        link_obj = LinkPago.objects.get(order_id=order_id)
        if link_obj.payzen_token_url:
            return render(request, 'autoredirect_payzen.html', {
                'target_url': link_obj.payzen_token_url,
                'card_code': link_obj.payzen_card_code,
                'monto': link_obj.monto,
                'descripcion': link_obj.descripcion
            })
        elif link_obj.link:
            return redirect(link_obj.link)
    except LinkPago.DoesNotExist:
        if str(order_id).isdigit():
            try:
                link_obj = LinkPago.objects.get(id=int(order_id))
                if link_obj.payzen_token_url:
                    return render(request, 'autoredirect_payzen.html', {
                        'target_url': link_obj.payzen_token_url,
                        'card_code': link_obj.payzen_card_code,
                        'monto': link_obj.monto,
                        'descripcion': link_obj.descripcion
                    })
                elif link_obj.link:
                    return redirect(link_obj.link)
            except LinkPago.DoesNotExist:
                pass
    raise Http404("El enlace de pago solicitado no existe.")


def gestion_perfil(request):
    user_id = request.session.get('user_id')
    if not user_id:
        logger.debug("Perfil — sesión no encontrada, redirigiendo a login")
        return redirect('login_cliente')

    cliente = crud.get_cliente(user_id)
    if not cliente:
        logger.warning(f"Perfil — cliente id={user_id} no encontrado en DB")
        return redirect('login_cliente')

    # Usuarios secundarios no acceden al perfil
    if cliente.es_secundario:
        return redirect('crear_link')

    logger.debug(f"Perfil cargado — usuario={cliente.nombre} id={user_id}")

    if request.method == 'POST':
        data = {
            'nombre': request.POST.get('nombre'),
            'username': request.POST.get('username'),
            'email': request.POST.get('email'),
            'telefono': request.POST.get('telefono'),
            'password': request.POST.get('password') if request.POST.get('password') else None,
            'recibir_liquidacion_email': 'recibir_liquidacion_email' in request.POST,
        }

        logger.debug(f"Actualización de perfil — usuario={user_id} campos={[k for k, v in data.items() if v]}")

        confirm_password = request.POST.get('confirm_password')
        if data['password'] and data['password'] != confirm_password:
            logger.warning(f"Perfil — contraseñas no coinciden — usuario={user_id}")
            messages.error(request, "Las contraseñas no coinciden.")
        else:
            errors = crud.update_cliente(user_id, data)
            if not errors:
                logger.info(f"Perfil actualizado OK — usuario={user_id} nombre={data.get('nombre')} email={data.get('email')}")
                messages.success(request, "Perfil actualizado correctamente.")
                return redirect('perfil')
            else:
                logger.warning(f"Perfil — errores al actualizar — usuario={user_id} errores={errors}")
                for error in errors:
                    messages.error(request, error)

    return render(request, 'perfil.html', {'user': cliente})

def set_username(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login_cliente')
    
    if request.method == 'POST':
        username = request.POST.get('username', '').strip().lower()
        if len(username) < 3 or not username.replace('_', '').replace('.', '').isalnum():
            messages.error(request, 'El nombre de usuario es inválido.')
        else:
            if Cliente.objects.filter(username__iexact=username).exists():
                messages.error(request, 'Ese nombre de usuario ya está en uso.')
            else:
                cliente = crud.get_cliente(user_id)
                if cliente:
                    cliente.username = username
                    cliente.save()
                    messages.success(request, f'Nombre de usuario configurado como @{username}')
    
    return redirect('dashboard')


def gestion_operadores(request):
    """Vista para que el usuario principal gestione sus operadores secundarios."""
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login_cliente')

    cliente = crud.get_cliente(user_id)
    if not cliente or cliente.es_secundario:
        return redirect('crear_link')

    if request.method == 'POST':
        accion = request.POST.get('accion')

        # --- Crear nuevo operador ---
        if accion == 'crear':
            username = request.POST.get('username', '').strip()
            nombre   = request.POST.get('nombre', '').strip()
            password = request.POST.get('password', '').strip()
            operador, errors = crud.create_operador(user_id, username, nombre, password)
            if errors:
                for e in errors:
                    messages.error(request, e)
            else:
                messages.success(request, f'Operador @{operador.username} creado correctamente.')
            return redirect('operadores')

        # --- Bloquear / Desbloquear ---
        if accion in ('bloquear', 'desbloquear'):
            op_id = request.POST.get('operador_id')
            try:
                op = Cliente.objects.get(pk=op_id, principal=cliente, rol=Cliente.ROL_SECUNDARIO)
                op.bloqueado = (accion == 'bloquear')
                op.save()
                msg = 'bloqueado' if op.bloqueado else 'desbloqueado'
                messages.success(request, f'Operador @{op.username} {msg}.')
            except Cliente.DoesNotExist:
                messages.error(request, 'Operador no encontrado.')
            return redirect('operadores')

        # --- Editar ---
        if accion == 'editar':
            op_id = request.POST.get('operador_id')
            nombre = request.POST.get('nombre', '').strip()
            username = request.POST.get('username', '').strip().lower()
            password = request.POST.get('password', '').strip()
            try:
                op = Cliente.objects.get(pk=op_id, principal=cliente, rol=Cliente.ROL_SECUNDARIO)
                if nombre:
                    op.nombre = nombre.upper()
                if username:
                    if username != op.username and Cliente.objects.filter(username__iexact=username).exclude(pk=op.pk).exists():
                        messages.error(request, 'El nombre de usuario ya está en uso.')
                    else:
                        op.username = username
                if password:
                    from django.contrib.auth.hashers import make_password
                    if len(password) >= 6:
                        op.password = make_password(password)
                    else:
                        messages.error(request, 'La contraseña debe tener al menos 6 caracteres.')
                op.save()
                messages.success(request, f'Operador @{op.username} actualizado.')
            except Cliente.DoesNotExist:
                messages.error(request, 'Operador no encontrado.')
            return redirect('operadores')


        # --- Eliminar ---
        if accion == 'eliminar':
            op_id = request.POST.get('operador_id')
            ok, err = crud.delete_operador(op_id, user_id)
            if ok:
                messages.success(request, 'Operador eliminado.')
            else:
                messages.error(request, err)
            return redirect('operadores')

    operadores = crud.list_operadores(user_id)
    # Links del negocio con info de quién los creó
    todos_links = crud.list_links_for_cliente(user_id).select_related('creado_por')[:50]

    return render(request, 'gestion_operadores.html', {
        'user':       cliente,
        'operadores': operadores,
        'links':      todos_links,
    })


def mensajes_cliente(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login_cliente')

    cliente = crud.get_cliente(user_id)
    if not cliente:
        return redirect('login_cliente')

    if not cliente.acepto_tyc or cliente.version_tyc != _get_tyc_version_actual():
        return redirect('tyc')

    from .models import MensajeInterno, LinkPago as LP
    from django.utils import timezone

    # Marcar como leidos los mensajes del admin
    MensajeInterno.objects.filter(
        cliente=cliente, es_admin=True, leido=False
    ).update(leido=True)
    
    from .models import SesionChat

    sesion_activa = SesionChat.objects.filter(cliente=cliente, cerrada=False).first()

    if sesion_activa:
        mensajes = MensajeInterno.objects.filter(
            sesion=sesion_activa
        ).select_related('link_pago').order_by('fecha')
        chat_cerrado = False
    else:
        # Mostrar la ultima sesion cerrada como referencia historica
        ultima_sesion = SesionChat.objects.filter(cliente=cliente, cerrada=True).first()
        mensajes = MensajeInterno.objects.filter(
            sesion=ultima_sesion
        ).select_related('link_pago').order_by('fecha') if ultima_sesion else MensajeInterno.objects.none()
        chat_cerrado = True

    links     = LP.objects.filter(cliente=cliente).order_by('-created_at')[:50]
    no_leidos = mensajes.filter(es_admin=True, leido=False).count() if not chat_cerrado else 0
    ultimo_id = mensajes.last().id if mensajes.exists() else 0

    return render(request, 'mensajes_cliente.html', {
        'user':      cliente,
        'mensajes':  mensajes,
        'links':     links,
        'no_leidos': no_leidos,
        'ultimo_id': ultimo_id,
        'chat_cerrado': chat_cerrado,
    })


def enviar_mensaje_cliente(request):
    user_id = request.session.get('user_id')
    if not user_id or request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'No autorizado'}, status=401)

    cliente = crud.get_cliente(user_id)
    if not cliente:
        return JsonResponse({'ok': False, 'error': 'Cliente no encontrado'}, status=404)

    from .models import MensajeInterno, LinkPago as LP
    from django.conf import settings
    import threading
    from .models import MensajeInterno as MI
    
    MI.objects.filter(cliente=cliente, conversacion_cerrada=True).update(conversacion_cerrada=False)

    texto   = request.POST.get('texto', '').strip()
    link_id = request.POST.get('link_pago', '').strip()

    if not texto:
        return JsonResponse({'ok': False, 'error': 'El mensaje no puede estar vacio.'})

    link_obj = None
    if link_id:
        try:
            link_obj = LP.objects.get(id=link_id, cliente=cliente)
        except LP.DoesNotExist:
            pass

    sesion = _get_or_create_sesion_activa(cliente)

    msg = MensajeInterno.objects.create(
        cliente   = cliente,
        texto     = texto,
        es_admin  = False,
        leido     = False,
        link_pago = link_obj,
        sesion    = sesion,
    )
    logger.info(f"Mensaje enviado por cliente={cliente.id} msg_id={msg.id}")

    # Email en background — no bloquea la respuesta
    def enviar_email_con_delay():
        import time
        from django.utils import timezone
        from datetime import timedelta

        # Esperar 5 minutos
        time.sleep(300)

        # Verificar si el admin estuvo activo en los ultimos 5 minutos
        try:
            from app2.models import User_admin
            UMBRAL = timezone.now() - timedelta(minutes=5)
            admin_activo = User_admin.objects.filter(
                ultima_actividad_mensajes__gte=UMBRAL
            ).exists()

            if admin_activo:
                logger.info(f"Email nuevo mensaje omitido — admin activo en pagina — msg_id={msg.id}")
                return
        except Exception:
            pass

        try:
            from utils.email_utils import mail
            destinatarios = getattr(settings, 'EMAIL_RECEPTORES', None)
            if not destinatarios:
                destinatarios = [getattr(settings, 'EMAIL_RECEPTOR', 'pagotechnotificaciones@gmail.com')]

            mail(
                asunto=f"Nuevo mensaje de {cliente.nombre} — Pago Tech",
                destinatarios=destinatarios,
                template_html='emails/nuevo_mensaje.html',
                contexto={
                    'cliente_nombre': cliente.nombre.title(),
                    'cliente_email':  cliente.email,
                    'texto':          texto,
                    'link_pago':      link_obj,
                    'fecha':          msg.fecha.strftime('%d/%m/%Y %H:%M'),
                    'admin_url':      f'{settings.SITE_URL}/app2/mensajes/{cliente.id}/' if hasattr(settings, 'SITE_URL') else '/app2/mensajes/',
                },
            )
        except Exception as e:
            logger.error(f"Error enviando email nuevo mensaje: {e}")

    threading.Thread(target=enviar_email_con_delay, daemon=True).start()

    return JsonResponse({
        'ok': True,
        'msg': {
            'id':       msg.id,        # ← asegurarse que está
            'texto':    texto,
            'fecha':    msg.fecha.strftime('%d/%m/%Y %H:%M'),
            'order_id': link_obj.order_id if link_obj else None,
            'link_id':  link_obj.id if link_obj else None,
        }
    })
    
def poll_mensajes(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return JsonResponse({'mensajes': []})

    cliente = crud.get_cliente(user_id)
    if not cliente:
        return JsonResponse({'mensajes': []})

    from .models import MensajeInterno

    ultimo_id = int(request.GET.get('ultimo_id', 0))

    nuevos = MensajeInterno.objects.filter(
        cliente=cliente,
        id__gt=ultimo_id
    ).select_related('link_pago').order_by('id')

    # Marcar admin como leidos
    nuevos.filter(es_admin=True, leido=False).update(leido=True)

    no_leidos = MensajeInterno.objects.filter(
        cliente=cliente, es_admin=True, leido=False
    ).count()

    return JsonResponse({
        'mensajes': [
            {
                'id':       m.id,
                'texto':    m.texto,
                'fecha':    m.fecha.strftime('%d/%m/%Y %H:%M'),
                'es_admin': m.es_admin,
                'order_id': m.link_pago.order_id if m.link_pago else None,
                'link_id':  m.link_pago.id if m.link_pago else None,
            }
            for m in nuevos
        ],
        'no_leidos': no_leidos,
    })
    
def finalizar_chat_cliente(request):
    user_id = request.session.get('user_id')
    if not user_id or request.method != 'POST':
        return JsonResponse({'ok': False}, status=400)

    cliente = crud.get_cliente(user_id)
    if not cliente:
        return JsonResponse({'ok': False}, status=404)

    from .models import MensajeInterno
    from django.conf import settings
    from django.utils import timezone
    import threading

    from .models import SesionChat

    sesion = SesionChat.objects.filter(cliente=cliente, cerrada=False).first()
    if not sesion:
        return JsonResponse({'ok': False, 'error': 'No hay conversacion activa para finalizar.'})

    # Solo mensajes de esta sesion
    mensajes_qs = MensajeInterno.objects.filter(sesion=sesion).order_by('fecha')
    if not mensajes_qs.exists():
        return JsonResponse({'ok': False, 'error': 'La sesion no tiene mensajes.'})

    # Cerrar la sesion
    from django.utils import timezone as tz
    sesion.cerrada      = True
    sesion.fecha_cierre = tz.now()
    sesion.save()

    # Evaluar antes del thread
    mensajes_lista = [
        {
            'texto':    m.texto,
            'fecha':    m.fecha.strftime('%d/%m/%Y %H:%M'),
            'es_admin': m.es_admin,
        }
        for m in mensajes_qs
    ]
    total          = len(mensajes_lista)
    fecha_cierre   = timezone.now().strftime('%d/%m/%Y %H:%M')
    cliente_nombre = cliente.nombre.title()
    cliente_email  = cliente.email
    cliente_id_val = cliente.id

    def enviar_resumenes():
        try:
            from utils.email_utils import mail_con_pdf
            from django.template.loader import render_to_string
            from weasyprint import HTML

            # Generar PDF
            html_pdf = render_to_string('emails/resumen_chat_pdf.html', {
                'cliente_nombre': cliente_nombre,
                'fecha_cierre':   fecha_cierre,
                'total_mensajes': total,
                'mensajes':       mensajes_lista,
            })
            pdf_bytes = HTML(string=html_pdf).write_pdf()
            pdf_nombre = f"resumen_chat_{cliente_nombre.replace(' ', '_')}_{fecha_cierre[:10].replace('/', '-')}.pdf"

            # Contexto para el email
            ctx_cliente = {
                'cliente_nombre': cliente_nombre,
                'fecha_cierre':   fecha_cierre,
                'total_mensajes': total,
                'es_admin':       False,
            }
            ctx_admin = {
                'cliente_nombre': cliente_nombre,
                'fecha_cierre':   fecha_cierre,
                'total_mensajes': total,
                'es_admin':       True,
            }

            # Email al comercio
            if cliente_email:
                mail_con_pdf(
                    asunto=f"Resumen de tu conversacion con Pago Tech — {fecha_cierre[:10]}",
                    destinatarios=[cliente_email],
                    template_html='emails/resumen_chat_email.html',
                    contexto=ctx_cliente,
                    pdf_bytes=pdf_bytes,
                    pdf_nombre=pdf_nombre,
                )

            # Email al admin
            from django.conf import settings
            destinatarios_admin = getattr(settings, 'EMAIL_RECEPTORES', None)
            if not destinatarios_admin:
                destinatarios_admin = [getattr(settings, 'EMAIL_RECEPTOR', 'pagotechnotificaciones@gmail.com')]

            mail_con_pdf(
                asunto=f"Chat finalizado con {cliente_nombre} — {fecha_cierre[:10]}",
                destinatarios=destinatarios_admin,
                template_html='emails/resumen_chat_email.html',
                contexto=ctx_admin,
                pdf_bytes=pdf_bytes,
                pdf_nombre=pdf_nombre,
            )

        except Exception as e:
            logger.error(f"Error enviando resumen con PDF: {e}")

def ping_mensajes(request):
    user_id = request.session.get('user_id')
    if not user_id or request.method != 'POST':
        return JsonResponse({'ok': False})
    from django.utils import timezone
    Cliente.objects.filter(id=user_id).update(
        ultima_actividad_mensajes=timezone.now()
    )
    return JsonResponse({'ok': True})

def _get_or_create_sesion_activa(cliente):
    from .models import SesionChat
    sesion = SesionChat.objects.filter(cliente=cliente, cerrada=False).first()
    if not sesion:
        sesion = SesionChat.objects.create(cliente=cliente)
    return sesion